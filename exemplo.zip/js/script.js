$(document).ready(() => {
	
	$('#formulario').on('click', () => {
		$.post('formulario.html', data => { 
			$('#pagina').html(data)
		})
	})

	
	})


	